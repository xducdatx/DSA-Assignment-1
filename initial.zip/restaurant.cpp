#include "main.h"

void simulate(string filename, restaurant* r)
{

}

